import java.util.ArrayList;
class Product {
    private int id;
    private String name;
    private double price;
    
    public Product(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }
    
    public int getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
}

// Customer Class
class Customer {
    private int customerId;
    private String name;
    
    public Customer(int customerId, String name) {
        this.customerId = customerId;
        this.name = name;
    }
    
    public int getCustomerId() { return customerId; }
    public String getName() { return name; }
}

// Cart Class


class Cart {
    private ArrayList<Product> products;
    
    public Cart() {
        this.products = new ArrayList<>();
    }
    
    public void addProduct(Product product) {
        products.add(product);
        System.out.println(product.getName() + " added to the cart.");
    }
    
    public double calculateTotal() {
        double total = 0;
        for (Product p : products) {
            total += p.getPrice();
        }
        return total;
    }
    
    public void showCart() {
        System.out.println("\nCart Items:");
        for (Product p : products) {
            System.out.println(p.getName() + " - $" + p.getPrice());
        }
        System.out.println("Total: $" + calculateTotal());
    }
}

// Order Class
class Order {
    private Customer customer;
    private Cart cart;
    
    public Order(Customer customer, Cart cart) {
        this.customer = customer;
        this.cart = cart;
    }
    
    public void placeOrder() {
        System.out.println("\nOrder placed successfully for " + customer.getName());
        cart.showCart();
    }
}

// Main Class to run the program
public class Main {
    public static void main(String[] args) {
        Customer customer = new Customer(1, "John Doe");
        Cart cart = new Cart();
        
        // Adding products
        Product p1 = new Product(101, "Laptop", 800);
        Product p2 = new Product(102, "Mouse", 20);
        Product p3 = new Product(103, "Keyboard", 50);
        
        cart.addProduct(p1);
        cart.addProduct(p2);
        cart.addProduct(p3);
        
        // Show cart & Place order
        cart.showCart();
        Order order = new Order(customer, cart);
        order.placeOrder();
    }
}